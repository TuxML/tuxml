from pytest import raises
from unittest import TestCase  #Usefull when testing classes